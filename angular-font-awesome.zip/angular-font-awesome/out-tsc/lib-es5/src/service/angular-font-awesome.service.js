import { Injectable } from '@angular/core';
var AngularFontAwesomeService = (function () {
    function AngularFontAwesomeService() {
    }
    return AngularFontAwesomeService;
}());
export { AngularFontAwesomeService };
AngularFontAwesomeService.decorators = [
    { type: Injectable },
];
/**
 * @nocollapse
 */
AngularFontAwesomeService.ctorParameters = function () { return []; };
function AngularFontAwesomeService_tsickle_Closure_declarations() {
    /** @type {?} */
    AngularFontAwesomeService.decorators;
    /**
     * @nocollapse
     * @type {?}
     */
    AngularFontAwesomeService.ctorParameters;
}
//# sourceMappingURL=angular-font-awesome.service.js.map