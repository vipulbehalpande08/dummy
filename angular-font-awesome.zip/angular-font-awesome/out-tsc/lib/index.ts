export { AngularFontAwesomeComponent } from './src/component/angular-font-awesome.component';
export { AngularFontAwesomeService } from './src/service/angular-font-awesome.service';
export { AngularFontAwesomeModule } from './src/angular-font-awesome.module';
