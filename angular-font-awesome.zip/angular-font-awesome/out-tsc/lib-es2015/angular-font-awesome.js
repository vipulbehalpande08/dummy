/**
 * Generated bundle index. Do not edit.
 */
export { AngularFontAwesomeComponent, AngularFontAwesomeService, AngularFontAwesomeModule } from './index';
//# sourceMappingURL=angular-font-awesome.js.map