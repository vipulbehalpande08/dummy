export declare class AngularFontAwesomeService {
    constructor();
}
