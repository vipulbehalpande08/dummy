import { Injectable } from '@angular/core';
export class AngularFontAwesomeService {
    constructor() { }
}
AngularFontAwesomeService.decorators = [
    { type: Injectable },
];
/**
 * @nocollapse
 */
AngularFontAwesomeService.ctorParameters = () => [];
function AngularFontAwesomeService_tsickle_Closure_declarations() {
    /** @type {?} */
    AngularFontAwesomeService.decorators;
    /**
     * @nocollapse
     * @type {?}
     */
    AngularFontAwesomeService.ctorParameters;
}
//# sourceMappingURL=angular-font-awesome.service.js.map