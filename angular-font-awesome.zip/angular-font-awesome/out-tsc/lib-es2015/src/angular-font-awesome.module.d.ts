export declare class AngularFontAwesomeModule {
}
