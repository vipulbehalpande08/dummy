import { OnChanges, SimpleChanges } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { CounterParams, Styles } from '@fortawesome/fontawesome-svg-core';
import { FaLayersComponent } from './layers.component';
import * as ɵngcc0 from '@angular/core';
export declare class FaLayersCounterComponent implements OnChanges {
    private parent;
    private sanitizer;
    content: string;
    title?: string;
    styles?: Styles;
    classes?: string[];
    renderedHTML: SafeHtml;
    constructor(parent: FaLayersComponent, sanitizer: DomSanitizer);
    ngOnChanges(changes: SimpleChanges): void;
    protected buildParams(): CounterParams;
    private updateContent;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FaLayersCounterComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<FaLayersCounterComponent, "fa-layers-counter", never, {
    "classes": "classes";
    "content": "content";
    "title": "title";
    "styles": "styles";
}, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGF5ZXJzLWNvdW50ZXIuY29tcG9uZW50LmQudHMiLCJzb3VyY2VzIjpbImxheWVycy1jb3VudGVyLmNvbXBvbmVudC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE9uQ2hhbmdlcywgU2ltcGxlQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRG9tU2FuaXRpemVyLCBTYWZlSHRtbCB9IGZyb20gJ0Bhbmd1bGFyL3BsYXRmb3JtLWJyb3dzZXInO1xuaW1wb3J0IHsgQ291bnRlclBhcmFtcywgU3R5bGVzIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2ZvbnRhd2Vzb21lLXN2Zy1jb3JlJztcbmltcG9ydCB7IEZhTGF5ZXJzQ29tcG9uZW50IH0gZnJvbSAnLi9sYXllcnMuY29tcG9uZW50JztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIEZhTGF5ZXJzQ291bnRlckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gICAgcHJpdmF0ZSBwYXJlbnQ7XG4gICAgcHJpdmF0ZSBzYW5pdGl6ZXI7XG4gICAgY29udGVudDogc3RyaW5nO1xuICAgIHRpdGxlPzogc3RyaW5nO1xuICAgIHN0eWxlcz86IFN0eWxlcztcbiAgICBjbGFzc2VzPzogc3RyaW5nW107XG4gICAgcmVuZGVyZWRIVE1MOiBTYWZlSHRtbDtcbiAgICBjb25zdHJ1Y3RvcihwYXJlbnQ6IEZhTGF5ZXJzQ29tcG9uZW50LCBzYW5pdGl6ZXI6IERvbVNhbml0aXplcik7XG4gICAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQ7XG4gICAgcHJvdGVjdGVkIGJ1aWxkUGFyYW1zKCk6IENvdW50ZXJQYXJhbXM7XG4gICAgcHJpdmF0ZSB1cGRhdGVDb250ZW50O1xufVxuIl19