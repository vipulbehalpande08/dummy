/**
 * Warns if parent component not existing.
 */
export declare const faWarnIfParentNotExist: (parent: any, parentName: string, childName: string) => void;
