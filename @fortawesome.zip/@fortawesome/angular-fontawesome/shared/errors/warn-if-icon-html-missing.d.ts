import { IconLookup } from '@fortawesome/fontawesome-svg-core';
export declare const faWarnIfIconDefinitionMissing: (iconSpec: IconLookup) => never;
