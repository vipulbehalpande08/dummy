export declare const faWarnIfIconSpecMissing: () => never;
