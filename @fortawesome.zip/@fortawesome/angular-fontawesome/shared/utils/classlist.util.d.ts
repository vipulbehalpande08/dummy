import { FaProps } from '../models/props.model';
/**
 * Fontawesome class list.
 * Returns classes array by props.
 */
export declare const faClassList: (props: FaProps) => string[];
