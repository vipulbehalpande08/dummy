import { ElementRef, OnChanges, OnInit, Renderer2, SimpleChanges } from '@angular/core';
import { SizeProp } from '@fortawesome/fontawesome-svg-core';
import * as ɵngcc0 from '@angular/core';
export declare class FaStackComponent implements OnInit, OnChanges {
    private renderer;
    private elementRef;
    /**
     * Size of the stacked icon.
     * Note that stacked icon is by default 2 times bigger, than non-stacked icon.
     * You'll need to set size using custom CSS to align stacked icon with a
     * simple one. E.g. `fa-stack { font-size: 0.5em; }`.
     */
    size?: SizeProp;
    constructor(renderer: Renderer2, elementRef: ElementRef);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<FaStackComponent>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<FaStackComponent, "fa-stack", never, {
    "size": "size";
}, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhY2suY29tcG9uZW50LmQudHMiLCJzb3VyY2VzIjpbInN0YWNrLmNvbXBvbmVudC5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFbGVtZW50UmVmLCBPbkNoYW5nZXMsIE9uSW5pdCwgUmVuZGVyZXIyLCBTaW1wbGVDaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTaXplUHJvcCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZSc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBGYVN0YWNrQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xuICAgIHByaXZhdGUgcmVuZGVyZXI7XG4gICAgcHJpdmF0ZSBlbGVtZW50UmVmO1xuICAgIC8qKlxuICAgICAqIFNpemUgb2YgdGhlIHN0YWNrZWQgaWNvbi5cbiAgICAgKiBOb3RlIHRoYXQgc3RhY2tlZCBpY29uIGlzIGJ5IGRlZmF1bHQgMiB0aW1lcyBiaWdnZXIsIHRoYW4gbm9uLXN0YWNrZWQgaWNvbi5cbiAgICAgKiBZb3UnbGwgbmVlZCB0byBzZXQgc2l6ZSB1c2luZyBjdXN0b20gQ1NTIHRvIGFsaWduIHN0YWNrZWQgaWNvbiB3aXRoIGFcbiAgICAgKiBzaW1wbGUgb25lLiBFLmcuIGBmYS1zdGFjayB7IGZvbnQtc2l6ZTogMC41ZW07IH1gLlxuICAgICAqL1xuICAgIHNpemU/OiBTaXplUHJvcDtcbiAgICBjb25zdHJ1Y3RvcihyZW5kZXJlcjogUmVuZGVyZXIyLCBlbGVtZW50UmVmOiBFbGVtZW50UmVmKTtcbiAgICBuZ09uSW5pdCgpOiB2b2lkO1xuICAgIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkO1xufVxuIl19