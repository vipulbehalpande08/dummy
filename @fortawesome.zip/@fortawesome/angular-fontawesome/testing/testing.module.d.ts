export declare class FontAwesomeTestingModule {
}
