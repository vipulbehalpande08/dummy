export { FontAwesomeTestingModule } from './testing.module';
