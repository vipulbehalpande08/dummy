"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.svgCoreVersion = '^1.2.27';
exports.angularFontawesomeVersion = '~0.6.0';
exports.iconPackVersion = '^5.12.1';
//# sourceMappingURL=versions.js.map