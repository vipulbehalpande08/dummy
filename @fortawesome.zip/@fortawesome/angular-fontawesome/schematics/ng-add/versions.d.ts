export declare const svgCoreVersion = "^1.2.27";
export declare const angularFontawesomeVersion = "~0.6.0";
export declare const iconPackVersion = "^5.12.1";
